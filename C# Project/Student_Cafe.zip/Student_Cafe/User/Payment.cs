﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
namespace AIUB_Student_Cafe
{
    public partial class Payment : Form
    {
        public String bill=null;
        int bb = 0;
        int bx = 0;
        SqlDataAdapter da = null;
        DataTable dt1 = new DataTable();
        
        string cs = ConfigurationManager.ConnectionStrings["dbcs"].ConnectionString;
        public Payment()
        {
            InitializeComponent();
            cartDB();
            richTextBox1.Text = "Total Price : " + bill;
        }
        public void cartDB()
        {
            SqlConnection con = new SqlConnection(cs);
          
            con.Open();
            da = new SqlDataAdapter("SELECT * FROM Selli", con);
            da.Fill(dt1);
            dataGridView1.DataSource = dt1;
            con.Close();
            
        }
        public void b(int b)
        {
            bb = b;
            bx = bx + bb;
            bill = bx.ToString();
            MessageBox.Show(bill);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(cs);
            
            MessageBox.Show("Thank you.");
            da = new SqlDataAdapter("DELETE FROM Selli", con);
            da.Fill(dt1);
            cartDB();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(cs);
           
            MessageBox.Show("Thank you.\n01700000000 this is our bkash number\n DO makepayment on that number.\n");
            MessageBox.Show("Thank you.");

            da = new SqlDataAdapter("DELETE FROM Selli", con);
            da.Fill(dt1);
            cartDB();
          
        }

        

        private void viewItemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Viewcart viewcart = new Viewcart();
            viewcart.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Main main = new Main();
            main.Show();
        }
    }
}
