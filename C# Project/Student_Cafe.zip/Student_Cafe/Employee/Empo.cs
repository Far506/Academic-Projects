﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
namespace AIUB_Student_Cafe
{
    public partial class Empo : Form
    {
        
        public Empo()
        {
            InitializeComponent();
        }
        
        string cs = ConfigurationManager.ConnectionStrings["dbcs"].ConnectionString;
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Cafe_Inventory ci = new Cafe_Inventory();
            ci.Show();
            
        }


        private void button2_Click_1(object sender, EventArgs e)
        {
            if (textBox1.Text != null)
            {
                this.Hide();
                ViewItem v = new ViewItem();
                v.Show();
            }
            else
            {
                MessageBox.Show("Enter Id for who you r ordering");
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            AddItem addItem = new AddItem();
            addItem.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        // private void button1_Click_1(object sender, EventArgs e)
        //  {
        //   this.Hide();
        //  Cafe_Inventory Ci = new Cafe_Inventory();
        //   this.Show();
        // }
    }
}

