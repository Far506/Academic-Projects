public class Publisher {
    int id;
    String name, contactNo;
    void setId(int id){
        this.id = id;
    }
    void setName(String name){
        this.name = name;
    }
    void setContactNo(String contactNo){
        this.contactNo = contactNo;
    }
    int getId(){
        return id;
    }
    String getName(){
        return name;
    }
    String getContactNo(){
        return contactNo;
    }
}